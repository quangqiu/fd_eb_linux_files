The test-files by this module are located in the morphlines-core module.
